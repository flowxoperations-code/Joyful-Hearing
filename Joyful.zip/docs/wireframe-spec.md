# Joyful Hearing Website Wireframe Spec (v1)

## 1) Product Goals
- Build immediate clinical trust for first-time visitors.
- Convert visitors to calls/WhatsApp/form appointments in under 2 clicks.
- Communicate clear service coverage: audiology + speech therapy.
- Rank locally for Lucknow intent searches.

## 2) Core Audience
- Parents seeking pediatric speech and hearing support.
- Adults with hearing loss/tinnitus concerns.
- Elderly caregivers searching for hearing aid support.
- ENT referrals looking for a trusted audiology partner.

## 3) UX Direction (Amplifon-inspired, localized)
- Clean, premium clinical interface.
- Conversion-first CTAs always visible.
- Educational blocks that reduce anxiety.
- Strong local proof: address, doctor credentials, testimonials.
- Mobile-first with sticky call/WhatsApp bar.

## 4) Information Architecture
- Home
- Services
- Hearing Tests
- Speech Therapy
- Hearing Aids
- About
- Testimonials
- FAQ
- Contact / Book Appointment

## 5) Homepage Wireframe

### Section A: Utility Strip
- Left: Opening hours + location label.
- Right: Phone, WhatsApp, email quick links.

### Section B: Main Header
- Logo (left).
- Nav links (center/right).
- Primary CTA: `Book Appointment`.
- Secondary CTA: `Call Now`.

### Section C: Hero
- Eyebrow: `Lucknow's Hearing & Speech Specialists`.
- H1: clear value proposition.
- Support copy: concise confidence-building text.
- CTAs: Book Appointment / WhatsApp / View Services.
- Right visual panel: modern gradient card + metrics.

### Section D: Quick Trust Metrics
- Years of experience.
- Patients supported.
- Certified care specialists.
- Avg response time.

### Section E: Services Grid
- Card set (5-6 cards):
  - Audiology Evaluation
  - Speech & Language Therapy
  - Digital Hearing Aid Fitting
  - Pediatric Hearing Care
  - Tinnitus Management
  - Home Visit / Follow-up
- Each card has one-line explanation + `Learn More`.

### Section F: Patient Journey (3 Steps)
- Step 1: Consultation & screening.
- Step 2: Diagnosis and personalized plan.
- Step 3: Device/therapy follow-up & outcomes.

### Section G: Specialist Credibility
- Lead specialist profile + credentials.
- Clinic differentiators.
- Micro trust badges (certified, evidence-based, family-friendly care).

### Section H: Testimonials + FAQ
- Rotating or card testimonials.
- 5-7 practical FAQs for first-time patients.

### Section I: Contact & Appointment
- Address, map link, clinic timings.
- Appointment form fields:
  - Name
  - Phone
  - Service needed
  - Preferred date
  - Message
- Final CTA bar with phone + WhatsApp.

### Section J: Footer
- Navigation shortcuts.
- Legal pages (privacy/terms placeholder).
- Copyright + local service area.

## 6) Visual System
- Primary blue: `#123B83`
- Accent red: `#D32733`
- Background light: `#F3F7FF`
- Deep navy text: `#101B34`
- Surface white: `#FFFFFF`

Typography:
- Headings: `Sora`
- Body: `Source Sans 3`

Style notes:
- Rounded cards with soft depth.
- Wave gradients in hero and section dividers.
- Motion limited to reveal/fade/slide; avoid distraction.

## 7) Conversion Elements (MVP)
- Sticky CTA on mobile: `Call` and `WhatsApp`.
- Repeated appointment CTA every 2 sections.
- Contact form above footer.
- Click-to-call and click-to-chat in header and hero.

## 8) SEO / Local Search Baseline
- Pages target local intent keywords (`hearing clinic in Lucknow`, `speech therapy in Lucknow`).
- Structured data: `MedicalClinic` + LocalBusiness details.
- Dedicated pages for Hearing Test and Speech Therapy.
- Google Business Profile consistency with NAP details.

## 9) Build Scope for Design Phase 1
- Responsive homepage mock in code.
- Color and typography tokens.
- Reusable section components.
- Placeholder content ready for clinic-approved copy.
