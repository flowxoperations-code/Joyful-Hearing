# Joyful Hearing Website QA Evals

## Purpose
This eval framework is designed to test whether the website is truly production-ready and visually consistent at a "world-class" standard.

## Scoring Model
Rate each dimension from 1 to 5 on every page (`index.html`, `services.html`, `speech-therapy.html`, `hearing-test.html`, `contact.html`).

1. `1 - Poor`: obvious breakage, weak hierarchy, unclear CTA.
2. `2 - Needs work`: functional but inconsistent and visually unpolished.
3. `3 - Good`: solid and clean, minor inconsistencies remain.
4. `4 - Strong`: coherent premium experience with high trust.
5. `5 - Exceptional`: highly refined, distinctive, and conversion-ready.

Target for sign-off:
- No dimension below 4.
- Average score across all dimensions >= 4.4.

## Core Dimensions

### 1) Design Quality
- Typography hierarchy is clear in every section.
- Card sizes, radii, and shadow depth are consistent.
- Colors follow Joyful brand palette (blue/red/warm accents) without random deviations.
- Visual rhythm is stable (section spacing and margins align across pages).

### 2) Experience Quality
- Primary actions are always clear: `Book Appointment`, `Call`, `WhatsApp`.
- Navigation is predictable and active state highlights current page.
- No dead-end sections; each page has next-action pathways.
- Mobile bottom action bar remains usable and non-overlapping.

### 3) Emotional Tone / Feeling
- First impression is trustworthy, caring, and clinically competent.
- Content feels human and reassuring, not generic filler.
- Visual weight is balanced between authority and warmth.

### 4) Modernity
- Layout avoids dated stacking and crowded text walls.
- Components use contemporary spacing, contrast, and interaction patterns.
- Motion and transitions are subtle, not distracting.

### 5) Boundary Push (without hurting clarity)
- Brand identity is clearly visible (not a template clone).
- Visual polish feels intentional (hero, media, sections, CTA hierarchy).
- Practical conversion UX is retained while design remains premium.

## Page-Level Acceptance Criteria

### `index.html`
- Hero includes value proposition and immediate CTAs.
- Services, products, experts, gallery, videos, testimonials, and contact blocks are present.
- Mission and vision are visible before footer.

### `services.html`
- All three service groups are clearly separated.
- Care pathway is visible with step logic.
- Conversion CTA appears near both top and bottom.

### `speech-therapy.html`
- Core and specialized speech services are listed.
- Therapy pathway and FAQ are present.
- Mohini Yadav profile is complete and prominent.

### `hearing-test.html`
- Audiology scope and hearing aid support are both visible.
- Care journey steps are clear.
- Ashish Kumar Bharti profile is complete and prominent.

### `contact.html`
- Full clinic info, timings, and appointment form are visible.
- Map embed renders correctly.
- Mission and vision still visible (consistency with brand story).

## Functional QA Checklist
- All top nav links resolve correctly.
- Logo click returns to `index.html`.
- Mobile menu toggle works and closes after link click.
- Telephone links use `tel:` and email link uses `mailto:`.
- WhatsApp links open the correct number.
- No local folder index browsing is required.

## Accessibility QA Checklist
- Headings are sequential and meaningful.
- Images include descriptive `alt` text.
- Inputs are labeled and keyboard focus is visible.
- Contrast for text against background is sufficient in dark cards.
- Motion respects `prefers-reduced-motion`.

## Performance QA Checklist
- Use WebPageTest/Lighthouse after deployment.
- Initial goals:
  - LCP <= 2.8s on 4G profile.
  - CLS <= 0.1.
  - TBT <= 200ms on mid-range device.
- Compress and cache all heavy images before final launch.

## Regression Command Pack
Run from project root:

```bash
rg -n "href=\"(index|services|speech-therapy|hearing-test|contact)\.html\"" index.html services.html speech-therapy.html hearing-test.html contact.html
rg -n "Caring for Communication|Our Mission|Our Vision|Ashish Kumar Bharti|Mohini Yadav|Your voice matters" index.html services.html speech-therapy.html hearing-test.html contact.html
rg -n "data-menu-btn|data-menu-panel|data-nav" index.html services.html speech-therapy.html hearing-test.html contact.html
```

## Final Sign-Off Template
Use this exact format for client review:

- Design Quality: `x/5`
- Experience Quality: `x/5`
- Emotional Tone: `x/5`
- Modernity: `x/5`
- Boundary Push: `x/5`
- Average: `x/5`
- Decision: `Pass / Rework`
- Rework notes: `specific pages + specific section names`
