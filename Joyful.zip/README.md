# Joyful Hearing Website

**Live Site**: [joyfulhearingandspeech.com](https://joyfulhearingandspeech.com)

Modern, responsive website for Joyful Hearing & Speech Clinic providing audiology and speech therapy services.

## Features

- 🎯 Comprehensive hearing solutions showcase
- 🗣️ Speech therapy expertise (children & adults)
- 📋 Interactive 10-question hearing assessment quiz
- 🔊 Tinnitus management information
- 📱 Fully responsive design
- ♿ Accessible UI/UX

## Tech Stack

- **Frontend**: HTML5, Vanilla CSS, Vanilla JavaScript
- **Hosting**: Hostinger
- **Deployment**: GitHub Actions (automated FTP)
- **Domain**: joyfulhearingandspeech.com

## Deployment

This repository uses GitHub Actions for automated deployment. Any push to `main` branch automatically deploys to Hostinger.

### Setup GitHub Secrets

Navigate to: Repository Settings → Secrets and variables → Actions

Add the following secrets:
- `FTP_SERVER`: Your Hostinger FTP server (e.g., ftp.yourdomain.com)
- `FTP_USERNAME`: Your Hostinger FTP username
- `FTP_PASSWORD`: Your Hostinger FTP password
- `FTP_SERVER_DIR`: Server directory (usually `public_html`)

### Manual Deployment

To manually trigger a deployment:
1. Go to Actions tab
2. Select "Deploy to Hostinger" workflow
3. Click "Run workflow"

## Local Development

```bash
# Clone the repository
git clone https://github.com/[username]/joyful-hearing-website.git

# Open in browser
open index.html
```

No build process required - pure static HTML/CSS/JS.

## Project Structure

```
├── index.html              # Homepage with quiz
├── about.html              # About clinic
├── services.html           # Hearing aid solutions
├── hearing-test.html       # Hearing test info
├── speech-therapy.html     # Speech therapy services
├── tinnitus-vertigo.html   # Tinnitus management
├── contact.html            # Contact form
├── assets/                 # Images and static assets
└── .github/
    └── workflows/
        └── deploy.yml      # Automated deployment
```

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License

© 2026 Joyful Hearing & Speech Clinic. All rights reserved.
